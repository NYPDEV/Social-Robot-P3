﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SocialRobot.Application.SkypeApp
{
   public class Skype
    {
        private void CallCommand(string CallCmd)
        {
            SkypeCall scc = new SkypeCall(CallCmd, 5000000);
            scc.PlaceACall();
        }

        public void MakeCall(string Number_ID)
        {
            CallCommand(Number_ID);

        }
    }
}
