﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Calendar.v3;
using Google.Apis.Calendar.v3.Data;
using Google.Apis.Services;
using Google.Apis.Util.Store;

namespace SocialRobot.Application
{
    public class GoogleCalender
    {
        static string[] Scopes = { CalendarService.Scope.Calendar };//{ CalendarService.Scope.CalendarReadonly };
        static string ApplicationName = "Google Calendar API .NET Quickstart";
        Function.Text_To_Speech TTS = new Function.Text_To_Speech();

        public void CreateAppointment(string ReminderContent, DateTime ReminderTime)
        {
            UserCredential credential;

            using (var stream =
                new FileStream("client_secret.json", FileMode.Open, FileAccess.Read))
            {
                string credPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
                credPath = System.IO.Path.Combine(credPath, ".credentials/calendar-dotnet-quickstart.json");

                credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                    GoogleClientSecrets.Load(stream).Secrets,
                    Scopes,
                    "user",
                    CancellationToken.None,
                    new FileDataStore(credPath, true)).Result;
                Console.WriteLine("Credential file saved to: " + credPath);
            }

            // Create Google Calendar API service.
            var service = new CalendarService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });

            // Define parameters of request.
            Event newEvent = new Event()
            {
                Summary = ReminderContent,
                Location = "Singapore",
                Description = ReminderContent,
                Start = new EventDateTime()
                {
                    DateTime = ReminderTime,
                    TimeZone = "Asia/Singapore",
                },
                End = new EventDateTime()
                {
                    DateTime = ReminderTime,//DateTime.Parse("2017-03-01T09:00:00-09:30"),
                    TimeZone = "Asia/Singapore",
                },
                // Recurrence = new String[] { "RRULE:FREQ=DAILY;COUNT=2" },
                Attendees = new EventAttendee[] {
                              new EventAttendee() { Email = "elthef@hotmail.com" },
                              new EventAttendee() { Email = "elthef@gmail.com" },
                 },
                Reminders = new Event.RemindersData()
                {
                    UseDefault = false,
                    Overrides = new EventReminder[] {
                      new EventReminder() { Method = "email", Minutes = 24 * 60 },
                        new EventReminder() { Method = "sms", Minutes = 10 },
                 }
                }
            };

            String calendarId = "primary";

            EventsResource.InsertRequest request = service.Events.Insert(newEvent, calendarId);
            Event createdEvent = request.Execute();
            Console.WriteLine("Event created: {0}", createdEvent.HtmlLink);

        }

        DateTime ReminderTime;
        string ReminderContent;

        public void LoadReminder()
        {
            UserCredential credential;

            using (var stream =
                new FileStream("client_secret.json", FileMode.Open, FileAccess.Read))
            {
                string credPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
                credPath = System.IO.Path.Combine(credPath, ".credentials/calendar-dotnet-quickstart.json");

                credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                    GoogleClientSecrets.Load(stream).Secrets,
                    Scopes,
                    "user",
                    CancellationToken.None,
                    new FileDataStore(credPath, true)).Result;
                Console.WriteLine("Credential file saved to: " + credPath);
            }

            // Create Google Calendar API service.
            var service = new CalendarService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });

            // Define parameters of request.
            EventsResource.ListRequest request = service.Events.List("primary");
            request.TimeMin = DateTime.Now;
            request.ShowDeleted = false;
            request.SingleEvents = true;
            request.MaxResults = 10;
            request.OrderBy = EventsResource.ListRequest.OrderByEnum.StartTime;

            // List events.
            Events events = request.Execute();
            Console.WriteLine("Upcoming events:");
            if (events.Items != null && events.Items.Count > 0)
            {
                ReminderContent = events.Items[0].Summary;
                ReminderTime = events.Items[0].Start.DateTime.Value;
                //if (String.IsNullOrEmpty(ReminderTime))
                //{
                //    ReminderTime = events.Items[0].Start.Date;
                //}
                Console.WriteLine("{0} ({1})", ReminderContent, ReminderTime);
                SetAlarm();
            }
            else
            {
                Console.WriteLine("No upcoming events found.");
            }
            Console.Read();
        }

        Thread AlarmThread;

        private void SetAlarm()
        {
            if (AlarmThread != null)
            {
                if (AlarmThread.IsAlive)
                {
                    AlarmThread.Abort();
                }
            }
            AlarmThread = new Thread(new ThreadStart(AlarmLoop));
            AlarmThread.Start();
        }

        private void AlarmLoop()
        {
            while (DateTime.Now < ReminderTime)
            {
                ;
            }
            if (ReminderContent != null)
            {
                while (Function.Text_To_Speech.SpeakingMark) ;
                Thread.Sleep(3000);
                TTS.Speaking("excuse me sir. It's time for you to " + ReminderContent);
            }
        }
    }
}
