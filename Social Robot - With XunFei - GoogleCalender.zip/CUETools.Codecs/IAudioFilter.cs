﻿namespace CUETools.Codecs
{
    public interface IAudioFilter
    {
        IAudioDest AudioDest { set; }
    }
}
