﻿namespace CUETools.Codecs.FLAKE
{
    public enum SubframeType
    {
        Constant = 0,
        Verbatim = 1,
        Fixed = 8,
        LPC = 32
    }
}
