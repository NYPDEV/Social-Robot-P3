﻿namespace CUETools.Codecs.FLAKE
{
    public enum OrderMethod
    {
        /// <summary>
        /// Select orders based on Akaike's criteria
        /// </summary>
        Akaike = 0
    }
}
