﻿namespace CUETools.Codecs.FLAKE
{
    public enum ChannelMode
    {
        NotStereo = 0,
        LeftRight = 1,
        LeftSide = 8,
        RightSide = 9,
        MidSide = 10
    }
}
