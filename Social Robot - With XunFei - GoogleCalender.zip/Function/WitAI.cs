﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Web;
using System.Windows;
using System.Threading;
using SKYPE4COMLib;
using System.Xml;

namespace SocialRobot.Function
{
    public class WitAnalysis
    {
        Wit.Objects.O_NLP.RootObject oNLP = new Wit.Objects.O_NLP.RootObject();
        Wit.NLP.NLP_Processing vitNLP = new Wit.NLP.NLP_Processing();
        Application.IRKitManager IRKitManager = new Application.IRKitManager();
        Text_To_Speech TTS = new Text_To_Speech();
        Motor Motor = new Motor();
        string Intent = null;

        public async void StartProcessing(string Text)
        {
            try
            {
                string ModText = Wit.NLP.Pre_NLP_Processing.preprocessText(Text);

                string NLP_Text = null;

                NLP_Text = await vitNLP.ProcessWrittenText(Text);

                // If the audio file doesn't contain anything, or wit.ai doesn't understand it, a code 400 will be returned
                if (NLP_Text.Contains("The remote server returned an error: (400) Bad Request"))
                {
                    //Setting_Windows.WitFeedBack.Text = "Sorry, didn't get that. Could you please repeat yourself?";
                    //Setting_Windows.WitRaw.Text = nlp_text;
                    return;
                }

                //Setting_Windows.WitRaw.Text = nlp_text;

                oNLP = Wit.NLP.Post_NLP_Processing.ParseData(NLP_Text);

                // This codeblock dynamically casts the intent to the corresponding class
                // Check README.txt in Vitals.Brain
                Assembly objAssembly;
                objAssembly = Assembly.GetExecutingAssembly();

                Type classType = objAssembly.GetType("SocialRobot.Wit.Vitals.Brain." + oNLP.entities.intent);

                //object obj = Activator.CreateInstance(classType);

                // MethodInfo mi = classType.GetMethod("makeSentence");

                object[] parameters = new object[1];
                parameters[0] = oNLP;

                //if (RuleName == "SGM_FUNC_AskTodayCustomWeather" || RuleName == "SGM_FUNC_AskTomorrowCustomWeather"/* || RuleName == "SGM_FUNC_天気"*/)
                //{
                try
                {
                    Intent = oNLP.entities.intent[0].value;
                }
                catch
                {
                    Intent = null;
                }
                GrammarAnalysis();
                //}
            }
            catch(Exception e)
            {
                while (Function.Text_To_Speech.SpeakingMark) ;
                Thread.Sleep(2000);
                TTS.Speaking("Sorry.");
            }
        }

        #region Application

        Application.ReadNews ReadNews = new Application.ReadNews();
        Application.GetWeather GetWeather = new Application.GetWeather();
        Application.SkypeApp.Skype Skype = new Application.SkypeApp.Skype();
        Application.GoogleCalender GoogleCalenderFunction = new Application.GoogleCalender();

        #endregion

        Random RanNum = new Random();
        public static string RobotName = "Ruth";
        public static string HomeCountry = "Singapore";
        public static string NewsType = null;
        public static string RealNewsType = null;
        public static string ContactsID = null;
        public static bool SkypeCallMark = false;
        public static string RemoteCommand = null;

        public void GrammarAnalysis()
        {
            int RandomNumber = RanNum.Next(1, 101);
            if(!Text_To_Speech.SpeakingMark)
            {
                switch (Intent)
                {
                    case "News":
                        NewsType = oNLP.entities.news[0].value;
                        if (NewsType == "next")
                        {
                            MainWindow.ReadNewsTimer.Stop();
                            TTS.Speaking("Ok,next news");
                            Thread.Sleep(2000);
                            ReadNews.flag_StartNewsReading = true;
                            ReadNews.NewsReadingFunction_Eng(RealNewsType);
                        }
                        else if (NewsType == "stop")
                        {
                            MainWindow.ReadNewsTimer.Stop();
                            TTS.Speaking("Ok, I will stop reading news.");
                            ReadNews.flag_StartNewsReading = false;
                        }
                        else
                        {
                            RealNewsType = NewsType;
                            ReadNews.NewsReadingFunction_Eng(NewsType);
                        }
                        break;

                    case "Weather":
                        {
                            string Location = null;
                            string WeatherDay = oNLP.entities.day[0].value;
                            try
                            {
                                Location = oNLP.entities.location[0].value;
                            }
                            catch
                            {
                                Location = "singapore";
                            }
                            GetWeather.GetTheWeather(Location, WeatherDay);
                        }
                        break;

                    case "Conversation":
                        string Conversation = oNLP.entities.conversation[0].value;
                        ConversationResponse(Conversation);
                        break;

                    case "Command":
                        string Command = oNLP.entities.command[0].value;
                        CommandResponse(Command);
                        break;

                    case "SkypePhoneCall":
                        string Contact = oNLP.entities.skype[0].value;
                        string PhoneNumber = null;
                        try
                        {
                            string MyXMLFilePath = AppDomain.CurrentDomain.BaseDirectory + @"Database\ContactsData.xml";
                            XmlDocument MyXmlDoc = new XmlDocument();
                            MyXmlDoc.Load(MyXMLFilePath);
                            XmlNode RootNode = MyXmlDoc.SelectSingleNode("Users");
                            XmlNodeList FirstLevelNodeList = RootNode.ChildNodes;
                            foreach (XmlNode Node in FirstLevelNodeList)
                            {
                                XmlNode SecondLevelNode1 = Node.FirstChild;
                                if (SecondLevelNode1.InnerText == Contact)
                                {
                                    XmlNode SecondLevelNode2 = Node.ChildNodes[1];
                                    PhoneNumber = SecondLevelNode2.InnerText;
                                }
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Error while getting the contact's data.");
                        }
                        Motor.RightArmRaise();
                        Function.FaceLED.Instance.Happy();
                        TTS.Speaking("OK, I'm calling " /*+ ResultName*/ + " for you.");
                        Thread.Sleep(2000);
                        if (PhoneNumber != null)
                        {
                            Skype.MakeCall(PhoneNumber);
                            MainWindow.IsListeningFromUser = true;
                            SkypeCallMark = true;
                        }
                        else
                        {
                            TTS.Speaking("Sorry I can not make phone call for this person.");
                            //SRG.UnloadGrammar(SRG.SGM_FUNC_SkypePhoneCallFinished);
                        }
                        break;

                    case "SkypeVideoCall":
                        Contact = oNLP.entities.skype[0].value;
                        try
                        {
                            string MyXMLFilePath = AppDomain.CurrentDomain.BaseDirectory + @"Database\VideoContactsData.xml";
                            XmlDocument MyXmlDoc = new XmlDocument();
                            MyXmlDoc.Load(MyXMLFilePath);
                            XmlNode RootNode = MyXmlDoc.SelectSingleNode("Users");
                            XmlNodeList FirstLevelNodeList = RootNode.ChildNodes;
                            foreach (XmlNode Node in FirstLevelNodeList)
                            {
                                XmlNode SecondLevelNode1 = Node.FirstChild;
                                if (SecondLevelNode1.InnerText == Contact)
                                {
                                    XmlNode SecondLevelNode2 = Node.ChildNodes[1];
                                    ContactsID = SecondLevelNode2.InnerText;
                                }
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Error while getting the contact's data.");
                        }
                        Motor.RightArmRaise();
                        Function.FaceLED.Instance.Happy();
                        TTS.Speaking("OK, I'm calling " /*+ ResultName*/ + " for you.");
                        Thread.Sleep(2000);
                        if (ContactsID != null)
                        {
                            Thread ThreadCall = new Thread(WaitForCall);
                            ThreadCall.Start();
                        }
                        else
                        {
                            TTS.Speaking("Sorry I can not make video call for this person.");
                            //SRG.UnloadGrammar(SRG.SGM_FUNC_SkypePhoneCallFinished);
                        }
                        break;

                    case "Reminder":
                        {
                            string ReminderDay = null;
                            try
                            {
                                ReminderDay = oNLP.entities.datetime[0].value.Day.ToString();
                            }
                            catch
                            {
                                try
                                {
                                    ReminderDay = oNLP.entities.day[0].value;
                                }
                                catch
                                {
                                    ReminderDay = "today";
                                }
                            }
                            string ReminderContent = oNLP.entities.reminder[0].value;
                            DateTime ReminderTime = oNLP.entities.datetime[0].value;
                            GoogleCalenderFunction.CreateAppointment(ReminderContent, ReminderTime);
                            if (ReminderTime.ToString("dd") == DateTime.Now.ToString("dd"))
                            {
                                TTS.Speaking("OK, I will remind you to " + ReminderContent + " at " + ReminderTime.ToString("hh") + ":" + ReminderTime.ToString("mm") + " " + ReminderTime.ToString("tt") + " today.");
                            }
                            else
                            {
                                TTS.Speaking("OK, I will remind you to " + ReminderContent + " at " + ReminderTime.ToString());
                            }
                            Thread.Sleep(100);
                            GoogleCalenderFunction.LoadReminder();
                        }
                        break;

                    case "RemoteControl":
                        RemoteCommand = oNLP.entities.remote[0].value;
                        IRKitManager.SendCommand(RemoteCommand);
                        break;

                    default:
                        if (RandomNumber <= 40)
                        {
                            TTS.Speaking("Sorry, I didn't get that.");
                        }
                        else if (RandomNumber <= 80)
                        {
                            TTS.Speaking("Sorry, I missed that.");
                        }
                        else
                        {
                            TTS.Speaking("That may be beyond my abilities at the moment.");
                        }
                        break;
                }

            }
            else
            {
                if (Intent == "Conversation")
                {
                    string Conversation = oNLP.entities.conversation[0].value;
                    if (Conversation == "StopTalking")
                    {
                        ConversationResponse(Conversation);
                    }
                }
            }
        }

        public void ConversationResponse(string Conversation)
        {
            int RandomNumber = RanNum.Next(1, 101);
            string TimeNow = DateTime.Now.ToString("hh") + ":" + DateTime.Now.ToString("mm") + " " + DateTime.Now.ToString("tt");
            switch (Conversation)//1. Later change to Xml database form!!!!!//2. Random answer
            {
                case "AskDate":
                    string DateNow = DateTime.Now.ToString("M");
                    TTS.Speaking("Today is " + DateNow);
                    break;

                case "AskDay":
                    string DayNow = DateTime.Now.ToString("dddd");
                    TTS.Speaking("Today is " + DayNow);
                    break;

                case "AskTime":
                    TTS.Speaking("The time is " + TimeNow);
                    break;

                case "BeingIntroduce":
                    TTS.Speaking("Nice to meet you too!");
                    break;

                case "AskIntroduction":
                    FaceLED.Instance.Happy();
                    Thread.Sleep(1000);
                    TTS.Speaking("My name is Ruth, I am a social robot designed by students from Nanyung Polytechnic and Kitakyushu National College of Technology. I have the abilities to recognize human emotions and natural language. I can also perform a variety of function such as news reading, weather broadcast, skype call or even music playing.");
                    break;

                case "AskIntroduceFunction":
                    Function.FaceLED.Instance.Happy();
                    Thread.Sleep(1000);
                    TTS.Speaking("I can perform lots of functions. I can turn on the lights by remote controlling. I can recognize human's facial expression and tell when you are happy or when you are sad. I can set reminders for taking medicine, appointments. I can also call for help when the elderly is in danger by making phone calls using Skype.");
                    break;

                case "HowAreYou":
                    if (RandomNumber < 25)
                    {
                        try
                        {
                            Function.FaceLED.Instance.Happy();
                        }
                        catch { }
                        Thread.Sleep(500);
                        TTS.Speaking("I am fine, thank you.");
                    }
                    else if (RandomNumber < 50)
                    {
                        try
                        {
                            Function.FaceLED.Instance.Happy();
                        }
                        catch { }
                        Thread.Sleep(500);
                        TTS.Speaking("Excellent. How are you?");
                    }
                    else if (RandomNumber < 75)
                    {
                        TTS.Speaking("Not bad.");
                    }
                    else
                    {
                        try
                        {
                            Function.FaceLED.Instance.Happy();
                        }
                        catch { }
                        Thread.Sleep(500);
                        TTS.Speaking("Pretty good.");
                    }
                    //if (Function.Vision.Instance.EmotionConfidence >= 70 && Function.Vision.Instance.Emotion != "Neutral")
                    //{
                    //    SRG.SRE_Speech.SpeakAsync("By the way, ");
                    //    EmotionDetection();
                    //}
                    break;

                case "AskRobotName":
                    Function.FaceLED.Instance.Happy();
                    Thread.Sleep(800);
                    if (RandomNumber < 30)
                    {
                        TTS.Speaking("My name is " + RobotName + ". What about you?");
                    }
                    else
                    {
                        TTS.Speaking("My name is " + RobotName + ".");
                    }
                    break;

                case "WhatIsSocialRobot":
                    Motor.ArmInitialize();
                    TTS.Speaking("According to Wikipedia, a social robot is an autonomous robot that interacts and communicates with humans or other autonomous physical agents by following social behaviors and rules attached to its role.");
                    Motor.LeftArmRest();
                    Motor.RightArmRest();
                    break;

                case "AskWhoDesign":
                    Motor.ArmInitialize();
                    TTS.Speaking("I was designed by students from Nanyang Polytechnic and Kitakyushu National College of Technology.");
                    Motor.LeftArmRest();
                    Motor.RightArmRest();
                    break;

                case "HowOldAreYou":
                    Motor.ArmInitialize();
                    TTS.Speaking("I was created in 2014. So, does that means I'm " + (DateTime.Now.Year - 2014) + " years old?");
                    Motor.LeftArmRest();
                    Motor.RightArmRest();
                    break;

                case "Compliment":
                    FaceLED.Instance.Smile();
                    Motor.ArmInitialize();
                    Thread.Sleep(500);
                    if (RandomNumber < 40)
                    {
                        TTS.Speaking("I'm very glad to hear that.");
                    }
                    else
                    {
                        TTS.Speaking("Thanks.");
                    }
                    break;

                case "Scold":
                    FaceLED.Instance.Sad();
                    Thread.Sleep(500);
                    if (RandomNumber < 40)
                    {
                        TTS.Speaking("I'm just trying to help you.");
                    }
                    else
                    {
                        TTS.Speaking("I am so sorry.");
                    }
                    break;

                case "ThankYou":
                    try
                    {
                        Function.FaceLED.Instance.Happy();
                    }
                    catch { }
                    Thread.Sleep(500);
                    if (RandomNumber < 33)
                    {
                        TTS.Speaking("You are welcome.");
                    }
                    else if (RandomNumber < 66)
                    {
                        TTS.Speaking("My pleasure.");
                    }
                    else
                    {
                        TTS.Speaking("No problem.");
                    }
                    break;

                case "GoodMorning":
                    if (DateTime.Now.Hour >= 6 && DateTime.Now.Hour < 12)
                    {
                        if (RandomNumber < 50)
                        {
                            TTS.Speaking("Morning.");
                        }
                        else
                        {
                            TTS.Speaking("Good morning.");
                        }
                    }
                    else
                    {
                        if (RandomNumber < 50)
                        {
                            TTS.Speaking("Good morning. But it's " + TimeNow);
                        }
                        else
                        {
                            TTS.Speaking("It's " + TimeNow);
                        }
                    }
                    break;

                case "GoodAfternoon":
                    if (DateTime.Now.Hour >= 12 && DateTime.Now.Hour < 18)
                    {
                        TTS.Speaking("Good afternoon.");
                    }
                    else
                    {
                        if (RandomNumber < 50)
                        {
                            TTS.Speaking("Good afternoon. But it's " + TimeNow);
                        }
                        else
                        {
                            TTS.Speaking("It's " + TimeNow);
                        }
                    }
                    break;

                case "GoodEvening":
                    if (DateTime.Now.Hour >= 18 || DateTime.Now.Hour < 6)
                    {
                        TTS.Speaking("Good evening.");
                    }
                    else
                    {
                        if (RandomNumber < 50)
                        {
                            TTS.Speaking("Good evening. But it's " + TimeNow);
                        }
                        else
                        {
                            TTS.Speaking("It's " + TimeNow);
                        }
                    }
                    break;

                case "GoodNight":
                    if (MainWindow.UserName != "Unknown")
                    {
                        TTS.Speaking("Good night, " + MainWindow.UserName + ".");
                    }
                    else
                    {
                        TTS.Speaking("Good night.");
                    }
                    Thread.Sleep(3000);
                    Environment.Exit(0);
                    break;

                case "HaveARest":
                    if (MainWindow.UserName != "Unknown")
                    {
                        TTS.Speaking("Well, see you next time, " + MainWindow.UserName + ".");
                    }
                    else
                    {
                        TTS.Speaking("OK, see you next time.");
                    }
                    Thread.Sleep(5000);
                    Environment.Exit(0);
                    break;

                case "GoingOut":
                    GetWeather.GetTheWeather(HomeCountry, "goingout");
                    break;

                case "SayHello":
                    if (RandomNumber < 33)
                    {
                        TTS.Speaking("Hello.");
                    }
                    else if (RandomNumber < 66)
                    {
                        TTS.Speaking("Hi");
                    }
                    else
                    {
                        TTS.Speaking("Greetings");
                    }
                    break;

                case "Goodbye":
                    if (RandomNumber < 50)
                    {
                        TTS.Speaking("Bye.");
                    }
                    else
                    {
                        TTS.Speaking("Goodbye");
                    }
                    break;

                case "UserRecognize":
                    if (MainWindow.UserName != "Unknown")
                    {
                        if (RandomNumber < 50)
                        {
                            TTS.Speaking("Sure, ");
                        }
                        else
                        {
                            TTS.Speaking("Of course, ");
                        }
                    }
                    else
                    {
                        TTS.Speaking("Sorry, I'm not sure who you are.");
                    }
                    break;

                case "TakePhoto":
                    FaceLED.Instance.Happy();
                    Motor.RightArmRaise();
                    break;

                case "StopTalking":
                    if (TTS.TextToSpeech.GetCurrentlySpokenPrompt() == null && !Function.Text_To_Speech.SpeakingMark)
                    {
                        TTS.Speaking("I think I am not talking at this moment.");
                    }
                    else
                    {
                        TTS.TextToSpeech.SpeakAsyncCancel(TTS.TextToSpeech.GetCurrentlySpokenPrompt());
                        TTS.Speaking("OK.");
                    }
                    break;

                default:
                    if (RandomNumber <= 40)
                    {
                        TTS.Speaking("Sorry, I didn't get that.");
                    }
                    else if (RandomNumber <= 80)
                    {
                        TTS.Speaking("Sorry, I missed that.");
                    }
                    else
                    {
                        TTS.Speaking("That may be beyond my abilities at the moment.");
                    }
                    break;
            }
            if (MainWindow.UserName != "Unknown")
            {
                TTS.Speaking(MainWindow.UserName);
            }
        }

        public void CommandResponse(string Command)
        {
            int RandomNumber = RanNum.Next(1, 101);
            switch (Command)
            {
                case "LookAtMe":
                    Motor.EyesBallInitialize();
                    if (RandomNumber <= 50)
                    {
                        FaceLED.Instance.Happy();
                    }
                    else
                    {
                        FaceLED.Instance.Surprise();
                    }
                    //if (MainWindow.Instance.EmotionConfidence >= 30 && MainWindow.Instance.Emotion != "Neutral")
                    //{
                    //    EmotionDetection();
                    //}
                    break;

                case "IAmHere":
                    if (RandomNumber <= 50)
                    {
                        TTS.Speaking("Oh, Hi.");
                    }
                    else
                    {
                        TTS.Speaking("Oh, Hello.");
                    }
                    Motor.RightArmRaise();
                    break;

                case "EyesOpen":
                    Motor.EyesOpen();
                    break;

                case "EyesClose":
                    Motor.EyesClose();
                    break;

                case "AskSmile":
                    FaceLED.Instance.Happy();
                    break;

                case "LeftArmRaise":
                    Motor.LeftArmInitialize();
                    break;

                case "RightArmRaise":
                    Motor.RightArmInitialize();
                    break;

                default:
                    if (RandomNumber <= 40)
                    {
                        TTS.Speaking("Sorry, I didn't get that.");
                    }
                    else if (RandomNumber <= 80)
                    {
                        TTS.Speaking("Sorry, I missed that.");
                    }
                    else
                    {
                        TTS.Speaking("That may be beyond my abilities at the moment.");
                    }
                    break;
            }
            if (MainWindow.UserName != "Unknown")
            {
                TTS.Speaking(MainWindow.UserName);
            }
        }

        public void WaitForCall()
        {
            try
            {
                Skype skype = new Skype();
                string SkypeID = ContactsID;
                Call call = skype.PlaceCall(SkypeID);
                do
                {
                    Thread.Sleep(1);
                } while (call.Status != TCallStatus.clsInProgress && call.Status != TCallStatus.clsCancelled);
                if (call.Status == TCallStatus.clsInProgress)
                {
                    MainWindow.IsListeningFromUser = true;
                    SkypeCallMark = true;
                    call.StartVideoSend();
                }
                else
                {
                    TTS.Speaking("Cancel");
                }
            }
            catch
            {
                TTS.Speaking("Sorry I can not make video call for this person.");
                //SRG.UnloadGrammar(SRG.SGM_FUNC_SkypePhoneCallFinished);
            }
        }
    }
}
