﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Threading;
using System.Configuration;
using System.IO;
using NAudio.Wave;
using System.Windows.Threading;
using CUETools.Codecs;
using CUETools.Codecs.FLAKE;
using System.Net;
using System.Speech.Recognition;
using System.Speech.Recognition.SrgsGrammar;
using System.Speech.Synthesis;
using System.Windows;
using WindowsInput;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Globalization;
using WindowsMicrophoneMuteLibrary;

namespace SocialRobot.Function
{
    class FaceLED
    {
        private SerialPort LED = new SerialPort();
        private FaceLED()
        {
            LED.PortName = ConfigurationManager.AppSettings["MBED_COM_PORT_NAME"].ToString();//For adjust com port, go to app config to change.
            LED.BaudRate = Convert.ToInt32(9600);
            LED.Handshake = System.IO.Ports.Handshake.None;
            LED.Parity = Parity.None;
            LED.DataBits = 8;
            LED.StopBits = StopBits.One;
            LED.ReadTimeout = 200;
            LED.WriteTimeout = 50;
            try
            {
                LED.Open(); 
               
            }
            catch
            {
                MessageBox.Show("LED can not be detected! Enter Demo Mode!");
                MainWindow.DemoMode = true;
            }
        }

        private static FaceLED _instance = new FaceLED();

        public static FaceLED Instance
        {
            get
            {
                return _instance;
            }
        }

        public void Angry()
        {
           LED.WriteLine("angry");
        }

        public void Bluek()
        {
           LED.WriteLine("bluek");
        }

        public void Delicious()
        {
           LED.WriteLine("delicious");
        }

        public void Disgust()
        {
            LED.WriteLine("disgust");
        }

        public void Fear()
        {
            LED.WriteLine("fear");
        }

        public void Happy()
        {
            LED.WriteLine("happy");
        }

        public void Horny()
        {
            LED.WriteLine("horny");
        }

        public void Normal()
        {
            LED.WriteLine("normal");
        }

        public void Sad()
        {
            LED.WriteLine("sad");
        }

        public void Sleep()
        {
            LED.WriteLine("sleep");
        }

        public void Smile()
        {
            LED.WriteLine("smile");
        }

        public void Surprise()
        {
            LED.WriteLine("surprise");
        }

        public void Speaking()
        {
            LED.WriteLine("mouth");
            Thread.Sleep(35);
            LED.WriteLine("mouth1");
            Thread.Sleep(35);
            LED.WriteLine("mouth2");
            Thread.Sleep(35);
            LED.WriteLine("mouth3");
            Thread.Sleep(35);
            LED.WriteLine("mouth2");
            Thread.Sleep(35);
            LED.WriteLine("mouth1");
            Thread.Sleep(35);
            LED.WriteLine("mouth");
        }

        public void blank()
        {
            if (!Record.RecordingMark)
            {
                LED.WriteLine("blank");
            }
        }

        public void cheekblank()
        {
            if (!Record.RecordingMark)
            {
                LED.WriteLine("cheekblank");
            }
        }

        public void cheekgreen()
        {
            LED.WriteLine("blue");
        }

        public void cheekblue()
        {
            if (!Record.RecordingMark)
            {
                LED.WriteLine("green");
            }
        }

        public void cheekred()
        {
            if (!Record.RecordingMark)
            {
                LED.WriteLine("red");
            }
        }
    }

    public class Text_To_Speech
    {
        public SpeechSynthesizer TextToSpeech = new SpeechSynthesizer();
        public SpeechSynthesizer TextToSpeechCN = new SpeechSynthesizer();
        Speech_Recognition SR = new Speech_Recognition();

        public Text_To_Speech()
        {
            try
            {
                //TextToSpeech.SelectVoice("IVONA 2 Amy");
                TextToSpeech.SelectVoice("Microsoft Zira Desktop");
                TextToSpeech.SetOutputToDefaultAudioDevice();
                TextToSpeechCN.SelectVoice("Microsoft Huihui Desktop");
                TextToSpeechCN.SetOutputToDefaultAudioDevice();
            }
            catch
            {
                TextToSpeech.Speak("Please install text to speech voice pack!");
                Environment.Exit(0);
            }
            if (!MainWindow.DemoMode)
            {
                TextToSpeech.SpeakProgress += SpeakProgress;
                TextToSpeechCN.SpeakProgress += SpeakProgressCN;
            }

            if (!MainWindow.DemoMode)
            {
                TextToSpeech.SpeakCompleted += SpeakCompleted;
                TextToSpeechCN.SpeakCompleted += SpeakCompletedCN;
            }
            #region Stop and previous speech

            // variable to stop SpeakAsync
            var Current = TextToSpeech.GetCurrentlySpokenPrompt();
            if (Current != null)
                TextToSpeech.SpeakAsyncCancel(Current);

            #endregion Stop and previous speech
        }

        public void Speaking(string Sentence)
        {
            while (TextToSpeech.GetCurrentlySpokenPrompt() != null) ;
            Motor.Instance.EyesOpen();
            Motor.Instance.EyesInitialize();
            TextToSpeech.SpeakAsync(Sentence);
        }

        public void SpeakingCN(string Sentence)
        {
            Motor.Instance.EyesOpen();
            Motor.Instance.EyesInitialize();
            TextToSpeechCN.SpeakAsync(Sentence);
        }

        public static bool SpeakingMark = false;

        public void SpeakProgress(object sender, SpeakProgressEventArgs e)
        {
            SpeakingMark = true;
            MainWindow.FacialExpressionMark = false;
            try
            {
                if (!SR.MouthMuteMark)
                {
                    FaceLED.Instance.Speaking();
                }
                SR.SpeechRecognition.RecognizeAsyncCancel();
            }
            catch
            {
                MessageBox.Show("Error while speaking in progress.");
            }
        }

        public void SpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {
            SpeakingMark = false;
            MainWindow.FacialExpressionMark = true;
            TextToSpeech.SpeakCompleted -= SpeakCompleted;
            try
            {
                SR.SpeechRecognition.RecognizeAsync(RecognizeMode.Multiple);
            }
            catch
            {
                //MessageBox.Show("Error while speak completed.");
            }
            TextToSpeech.SpeakCompleted += SpeakCompleted;
            SR.MouthMuteMark = false;
        }

        public void SpeakProgressCN(object sender, SpeakProgressEventArgs e)
        {
            SpeakingMark = true;
            MainWindow.FacialExpressionMark = false;
            try
            {
                if (!SR.MouthMuteMark)
                {
                    FaceLED.Instance.Speaking();
                }
                SR.SpeechRecognition.RecognizeAsyncCancel();
            }
            catch
            {
                MessageBox.Show("语音转换文字时发生错误.");
            }
        }

        public void SpeakCompletedCN(object sender, SpeakCompletedEventArgs e)
        {
            SpeakingMark = false;
            MainWindow.FacialExpressionMark = true;
            SR.MouthMuteMark = false;
            //开启中文录音
        }
    }
}
