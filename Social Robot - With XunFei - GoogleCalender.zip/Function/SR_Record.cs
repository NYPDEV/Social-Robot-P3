﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using NAudio.Wave;
using System.Windows.Threading;
using CUETools.Codecs;
using CUETools.Codecs.FLAKE;
using System.Net;
using System.Speech.Recognition;
using System.Speech.Recognition.SrgsGrammar;
using System.Speech.Synthesis;
using System.Windows;
using System.Threading;
using WindowsInput;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.IO.Ports;
using System.Globalization;
using WindowsMicrophoneMuteLibrary;

namespace SocialRobot.Function
{
    public class Speech_Recognition
    {
        public SpeechRecognitionEngine SpeechRecognition = new SpeechRecognitionEngine(new System.Globalization.CultureInfo("en-US"));

        public string BaseFolder = AppDomain.CurrentDomain.BaseDirectory;

        public static string Language = "English";

        public Grammar SGM_FUNC_ReadNews;
        public Grammar SGM_FUNC_LanguageOption;
        public Grammar SGM_NewsOption;
        public Grammar SGM_FUNC_NextNews;
        public Grammar SGM_FUNC_StopReadNews;
        public Grammar SGM_ContinueReadNews_YesNo;

        public Grammar SGM_FUNC_AskWhatTimeNow;
        public Grammar SGM_FUNC_AskWhatDayIsToday;
        public Grammar SGM_FUNC_AskWhatDateIsToday;

        public Grammar SGM_FUNC_AskTodayCustomWeather;
        public Grammar SGM_FUNC_AskTomorrowCustomWeather;
        public Grammar SGM_FUNC_GoingOut;

        public Grammar SGM_DIAL_AskCountryPresidentOrPrimeMinister;

        public Grammar SGM_DIAL_Raise_Right_Hand;
        public Grammar SGM_DIAL_Raise_Left_Hand;

        public Grammar SGM_FUNC_COMPLEX_SetReminder;
        public Grammar SGM_FUNC_COMPLEX_SetReminderYesNo;

        public Grammar SGM_FUNC_Call;
        public Grammar SGM_FUNC_CallPerson;
        public Grammar SGM_FUNC_SkypePhoneCallFinished;

        public Grammar SGM_FUNC_Char;
        public Grammar SGM_FUNC_RegisterMode_YesNo;

        public Grammar SGM_FUNC_StartRadioStaion;
        public Grammar SGM_FUNC_StartRadioStationYesNo;
        public Grammar SGM_FUNC_StopRadioStation;
        public Grammar SGM_FUNC_StopRadioStationYesNo;

        public Grammar SGM_FUNC_ControlTV;
        public Grammar SGM_FUNC_ControlProjector;
        public Grammar SGM_FUNC_PowerOnOffTV;
        public Grammar SGM_FUNC_ChangeInputTV;
        public Grammar SGM_FUNC_MuteTV;
        public Grammar SGM_FUNC_upTV;
        public Grammar SGM_FUNC_downTV;
        public Grammar SGM_FUNC_leftTV;
        public Grammar SGM_FUNC_rightTV;
        public Grammar SGM_FUNC_enterTV;
        public Grammar SGM_FUNC_VolumePlusTV;
        public Grammar SGM_FUNC_VolumeMinusTV;
        public Grammar SGM_FUNC_ChannelPlusTV;
        public Grammar SGM_FUNC_ChannelMinusTV;
        public Grammar SGM_FUNC_MenuTV;

        public Grammar SGM_FUNC_ControlRadio;
        public Grammar SGM_FUNC_NextRadio;
        public Grammar SGM_FUNC_PreviousRadio;
        public Grammar SGM_FUNC_VolumeDownRadio;
        public Grammar SGM_FUNC_VolumeUpRadio;


        public Grammar SGM_FUNC_ControlFan;
        public Grammar SGM_FUNC_PowerOnOffFan;
        public Grammar SGM_FUNC_Speed;
        public Grammar SGM_FUNC_Timer;
        public Grammar SGM_FUNC_onUpDown;
        public Grammar SGM_FUNC_onLeftRightFan;

        public Grammar SGM_FUNC_PowerOnLight;
        public Grammar SGM_FUNC_PowerOffLight;

        public Grammar SGM_DIAL_SayHello;
        public Grammar SGM_DIAL_AskIntroduction;
        public Grammar SGM_DIAL_AskRobotHowAreYou;
        public Grammar SGM_DIAL_NiceToMeetYou;
        public Grammar SGM_DIAL_AskWhatIsSocialRobot;
        public Grammar SGM_DIAL_AskWhoDesign;
        public Grammar SGM_DIAL_GoodBye;
        public Grammar SGM_DIAL_Greeting;
        public Grammar SGM_DIAL_ThankYou;
        public Grammar SGM_DIAL_Scold;
        public Grammar SGM_DIAL_Compliment;
        public Grammar SGM_DIAL_AskRobotName;
        public Grammar SGM_DIAL_SwitchLanguageToChinese;
        public Grammar SGM_DIAL_SwitchLanguageToChinese_YesNo;
        public Grammar SGM_DIAL_SwitchLanguageToJapanese;
        public Grammar SGM_DIAL_SwitchLanguageToJapanese_YesNo;
        public Grammar SGM_DIAL_LookAtMe;
        public Grammar SGM_DIAL_Sleep;
        public Grammar SGM_DIAL_Sleep_YesNo;
        public Grammar SGM_DIAL_Emotion;
        public Grammar SGM_DIAL_Help;

        public void SpeechRecognized()
        {
            SRGS_GrammarModels();
            try
            {
                SpeechRecognition.SetInputToDefaultAudioDevice();
            }
            catch
            {
                MessageBox.Show("No audio input device.");
            }
            SpeechRecognition.RecognizeAsync(RecognizeMode.Multiple);
        }

        public void SRGS_GrammarModels()
        {
            try
            {
                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_FUNC_ReadNews = new Grammar(BaseFolder + @"Grammar\English\ReadNewsFunction\SGM_FUNC_ReadNews.xml");
                LoadGrammar(SGM_FUNC_ReadNews);

                SGM_FUNC_LanguageOption = new Grammar(BaseFolder + @"Grammar\English\ReadNewsFunction\SGM_LanguageOption.xml");

                SGM_NewsOption = new Grammar(BaseFolder + @"Grammar\English\ReadNewsFunction\SGM_NewsOption.xml");

                SGM_FUNC_NextNews = new Grammar(BaseFolder + @"Grammar\English\ReadNewsFunction\SGM_FUNC_NextNews.xml");

                SGM_FUNC_StopReadNews = new Grammar(BaseFolder + @"Grammar\English\ReadNewsFunction\SGM_FUNC_StopReadNews.xml");

                SGM_ContinueReadNews_YesNo = new Grammar(BaseFolder + @"Grammar\English\ReadNewsFunction\SGM_ContinueReadNews_YesNo.xml");
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_FUNC_AskWhatTimeNow = new Grammar(BaseFolder + @"Grammar\English\DateTimeFunction\SGM_FUNC_AskWhatTimeNow.xml");
                LoadGrammar(SGM_FUNC_AskWhatTimeNow);

                SGM_FUNC_AskWhatDayIsToday = new Grammar(BaseFolder + @"Grammar\English\DateTimeFunction\SGM_FUNC_AskWhatDayIsToday.xml");
                LoadGrammar(SGM_FUNC_AskWhatDayIsToday);

                SGM_FUNC_AskWhatDateIsToday = new Grammar(BaseFolder + @"Grammar\English\DateTimeFunction\SGM_FUNC_AskWhatDateIsToday.xml");
                LoadGrammar(SGM_FUNC_AskWhatDateIsToday);
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_FUNC_AskTodayCustomWeather = new Grammar(BaseFolder + @"Grammar\English\AskWeather\SGM_FUNC_AskTodayCustomWeather.xml");
                LoadGrammar(SGM_FUNC_AskTodayCustomWeather);

                SGM_FUNC_AskTomorrowCustomWeather = new Grammar(BaseFolder + @"Grammar\English\AskWeather\SGM_FUNC_AskTomorrowCustomWeather.xml");
                LoadGrammar(SGM_FUNC_AskTomorrowCustomWeather);

                SGM_FUNC_GoingOut = new Grammar(BaseFolder + @"Grammar\English\AskWeather\SGM_FUNC_GoingOut.xml");
                LoadGrammar(SGM_FUNC_GoingOut);
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_DIAL_AskCountryPresidentOrPrimeMinister = new Grammar(BaseFolder + @"Grammar\English\AskPresidentOrPrimeMinister\SGM_DIAL_AskCoutryPresidentOrPrimeMinister.xml");
                LoadGrammar(SGM_DIAL_AskCountryPresidentOrPrimeMinister);
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_DIAL_Raise_Right_Hand = new Grammar(BaseFolder + @"Grammar\English\Action\SGM_DIAL_Raise_Right_Hand.xml");
                LoadGrammar(SGM_DIAL_Raise_Right_Hand);

                SGM_DIAL_Raise_Left_Hand = new Grammar(BaseFolder + @"Grammar\English\Action\SGM_DIAL_Raise_Left_Hand.xml");
                LoadGrammar(SGM_DIAL_Raise_Left_Hand);
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_FUNC_COMPLEX_SetReminder = new Grammar(BaseFolder + @"Grammar\English\SetReminder\SGM_FUNC_COMPLEX_SetReminder.xml");
                SGM_FUNC_COMPLEX_SetReminder.Priority = 1;
                SGM_FUNC_COMPLEX_SetReminder.Weight = 1f;
                LoadGrammar(SGM_FUNC_COMPLEX_SetReminder);

                SGM_FUNC_COMPLEX_SetReminderYesNo = new Grammar(BaseFolder + @"Grammar\English\SetReminder\SGM_FUNC_COMPLEX_SetReminderYesNo.xml");
                SGM_FUNC_COMPLEX_SetReminderYesNo.Priority = 1;
                SGM_FUNC_COMPLEX_SetReminderYesNo.Weight = 1f;
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_FUNC_Call = new Grammar(BaseFolder + @"Grammar\English\Skype\SGM_FUNC_Call.xml");
                LoadGrammar(SGM_FUNC_Call);

                SGM_FUNC_CallPerson = new Grammar(BaseFolder + @"Grammar\English\Skype\SGM_FUNC_CallPerson.xml");

                SGM_FUNC_SkypePhoneCallFinished = new Grammar(BaseFolder + @"Grammar\English\Skype\SGM_FUNC_SkypePhoneCallFinished.xml");
                LoadGrammar(SGM_FUNC_SkypePhoneCallFinished);
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_FUNC_Char = new Grammar(BaseFolder + @"Grammar\English\Register\SGM_FUNC_Char.xml");

                SGM_FUNC_RegisterMode_YesNo = new Grammar(BaseFolder + @"Grammar\English\Register\SGM_FUNC_RegisterMode_YesNo.xml");
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_FUNC_StartRadioStaion = new Grammar(BaseFolder + @"Grammar\English\RadioFunction\SGM_FUNC_StartRadioStaion.xml");
                LoadGrammar(SGM_FUNC_StartRadioStaion);

                SGM_FUNC_StopRadioStation = new Grammar(BaseFolder + @"Grammar\English\RadioFunction\SGM_FUNC_StopRadioStation.xml");

                SGM_FUNC_StartRadioStationYesNo = new Grammar(BaseFolder + @"Grammar\English\RadioFunction\SGM_FUNC_StartRadioStationYesNo.xml");

                SGM_FUNC_StopRadioStationYesNo = new Grammar(BaseFolder + @"Grammar\English\RadioFunction\SGM_FUNC_StopRadioStationYesNo.xml");
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_FUNC_ControlRadio = new Grammar(BaseFolder + @"Grammar\English\iRKit\ControlRadio\SGM_FUNC_ControlRadio.xml");
                LoadGrammar(SGM_FUNC_ControlRadio);

                SGM_FUNC_NextRadio = new Grammar(BaseFolder + @"Grammar\English\iRKit\ControlRadio\SGM_FUNC_NextRadio.xml");

                SGM_FUNC_PreviousRadio = new Grammar(BaseFolder + @"Grammar\English\iRKit\ControlRadio\SGM_FUNC_PreviousRadio.xml");

                SGM_FUNC_VolumeUpRadio = new Grammar(BaseFolder + @"Grammar\English\iRKit\ControlRadio\SGM_FUNC_VolumeUpRadio.xml");

                SGM_FUNC_VolumeDownRadio = new Grammar(BaseFolder + @"Grammar\English\iRKit\ControlRadio\SGM_FUNC_VolumeDownRadio.xml");
                //////////////////////////////////////////////////////////////////////////////////////////

                //////////////////////////////////////////////////////////////////////////////////////////
                SGM_DIAL_SayHello = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_SayHello.xml");
                LoadGrammar(SGM_DIAL_SayHello);

                SGM_DIAL_AskIntroduction = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_AskIntroduction.xml");
                LoadGrammar(SGM_DIAL_AskIntroduction);

                SGM_DIAL_AskRobotHowAreYou = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_AskRobotHowAreYou.xml");
                LoadGrammar(SGM_DIAL_AskRobotHowAreYou);

                SGM_DIAL_NiceToMeetYou = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_NiceToMeetYou.xml");
                LoadGrammar(SGM_DIAL_NiceToMeetYou);

                SGM_DIAL_AskWhatIsSocialRobot = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_AskWhatIsSocialRobot.xml");
                LoadGrammar(SGM_DIAL_AskWhatIsSocialRobot);

                SGM_DIAL_AskWhoDesign = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_AskWhoDesign.xml");
                LoadGrammar(SGM_DIAL_AskWhoDesign);

                SGM_DIAL_GoodBye = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_GoodBye.xml");
                LoadGrammar(SGM_DIAL_GoodBye);

                SGM_DIAL_Greeting = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_Greeting.xml");
                LoadGrammar(SGM_DIAL_Greeting);

                SGM_DIAL_ThankYou = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_ThankYou.xml");
                LoadGrammar(SGM_DIAL_ThankYou);

                SGM_DIAL_Scold = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_Scold.xml");
                LoadGrammar(SGM_DIAL_Scold);

                SGM_DIAL_Compliment = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_Compliment.xml");
                LoadGrammar(SGM_DIAL_Compliment);

                SGM_DIAL_AskRobotName = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_AskRobotName.xml");
                LoadGrammar(SGM_DIAL_AskRobotName);

                SGM_DIAL_SwitchLanguageToChinese = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_SwitchLanguageToChinese.xml");
                LoadGrammar(SGM_DIAL_SwitchLanguageToChinese);

                SGM_DIAL_SwitchLanguageToChinese_YesNo = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_SwitchLanguageToChinese_YesNo.xml");

                SGM_DIAL_SwitchLanguageToJapanese = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_SwitchLanguageToJapanese.xml");
                LoadGrammar(SGM_DIAL_SwitchLanguageToJapanese);

                SGM_DIAL_SwitchLanguageToJapanese_YesNo = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_SwitchLanguageToJapanese_YesNo.xml");

                SGM_DIAL_LookAtMe = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_LookAtMe.xml");
                LoadGrammar(SGM_DIAL_LookAtMe);

                SGM_DIAL_Sleep = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_Sleep.xml");
                LoadGrammar(SGM_DIAL_Sleep);

                SGM_DIAL_Sleep_YesNo = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_Sleep_YesNo.xml");

                SGM_DIAL_Emotion = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_Emotion.xml");
                LoadGrammar(SGM_DIAL_Emotion);

                SGM_DIAL_Help = new Grammar(BaseFolder + @"Grammar\English\Greeting\SGM_DIAL_Help.xml");
                LoadGrammar(SGM_DIAL_Help);
                //////////////////////////////////////////////////////////////////////////////////////////
            }

            catch
            {

            }
        }

        public bool MouthMuteMark = false;

        void AudioLevelUpdate()
        {
            SpeechRecognition.AudioLevelUpdated += new EventHandler<AudioLevelUpdatedEventArgs>(SR_AudioLevelUpdated);
        }

        private void SR_AudioLevelUpdated(object sender, AudioLevelUpdatedEventArgs e)
        {
            SpeechRecognition.AudioLevelUpdated -= SR_AudioLevelUpdated;
        }

        //Grammar Load Unload Manager Part Start
        public void LoadGrammar(Grammar GrammarA)
        {
            if (!GrammarA.Loaded)
            {
                SpeechRecognition.LoadGrammar(GrammarA);
            }
            else
            {
                //Cannot load the same grammar twice
            }
        }

        public void UnloadGrammar(Grammar GrammarA)
        {
            if (GrammarA.Loaded)
            {
                SpeechRecognition.UnloadGrammar(GrammarA);
            }
            else
            {
                //Cannot unload the same grammar twice
            }
        }
        //Grammar Load Unload Manager Part End
    }

    public class Record
    {
        WitAnalysis WitAI = new WitAnalysis();
        Text_To_Speech TTS = new Text_To_Speech();
        //Google Speech API Part Start
        NAudio.Wave.WaveIn record = null;
        string save_wav = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDi‌​rectory, @"..\test.wav"));
        string save_flac = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDi‌​rectory, @"..\test.flac"));
        string api_key = "AIzaSyB0k39M9LDwuYcEsHHBCtfLXd5Cu3u94lY";
        NAudio.Wave.WaveFileWriter wavewriter = null;
        //Google Speech API Part Stop

        public static bool RecordingMark = false;
        public static bool RecordAnalysisMark = false;

        public void RecordStart()
        {
            if (record == null)
            {
                record = new NAudio.Wave.WaveIn();
                record.DeviceNumber = 0;
                record.WaveFormat = new NAudio.Wave.WaveFormat(44100, 16, 1);
                record.DataAvailable += Record_DataAvailable;
                record.StartRecording();
            }
            if (wavewriter == null)
            {
                wavewriter = new NAudio.Wave.WaveFileWriter(save_wav, record.WaveFormat);
            }
            RecordAnalysisMark = true;
        }

        private void Record_DataAvailable(object sender, NAudio.Wave.WaveInEventArgs e)
        {
            if (wavewriter == null) return;
            wavewriter.Write(e.Buffer, 0, e.BytesRecorded);
            wavewriter.Flush();
        }

        public async void RecordStop()
        {
            if (RecordAnalysisMark)
            {
                RecordAnalysisMark = false;
                if (record != null)
                {
                    record.StopRecording();
                    record.Dispose();
                    record = null;
                }
                if (wavewriter != null)
                {
                    wavewriter.Dispose();
                    wavewriter = null;
                }
                var sourceStream = new FileStream(save_wav, FileMode.Open);
                var audioSource = new WAVReader(null, sourceStream);

                try
                {
                    if (audioSource.PCM.SampleRate != 44100)
                    {
                        throw new InvalidOperationException("Incorrect frequency - WAV file must be at 16 KHz.");
                    }
                    var buff = new AudioBuffer(audioSource, 0x10000);

                    var flakeWriter = new FlakeWriter(save_flac, null, audioSource.PCM);
                    flakeWriter.CompressionLevel = 0;
                    while (audioSource.Read(buff, -1) != 0)
                    {
                        flakeWriter.Write(buff);
                    }

                    flakeWriter.Close();
                }
                finally
                {
                    audioSource.Close();
                }
                string lang = "en-US";
                byte[] save_byte = File.ReadAllBytes(save_flac);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://www.google.com/speech-api/v2/recognize?output=json&lang=" + lang + "&key=" + api_key);
                // HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://www.google.com/speech-api/v2/recognize?output=json&lang=" + "eng" + "&key=" + api_key);
                request.Method = "POST";
                request.ContentType = "audio/x-flac; rate=44100";
                request.ContentLength = save_byte.Length;
                request.GetRequestStream().Write(save_byte, 0, save_byte.Length);
                WebResponse response = await request.GetResponseAsync();
                StreamReader sr = new StreamReader(response.GetResponseStream());
                string read = sr.ReadToEnd();
                // string responseFromServer = (SR_Response.ReadToEnd());

                String[] jsons = read.Split('\n');
                string Text = null;
                float confidence;
                try
                {
                    foreach (String j in jsons)
                    {
                        dynamic jsonObject = Newtonsoft.Json.JsonConvert.DeserializeObject(j);
                        if (jsonObject == null || jsonObject.result.Count <= 0)
                        {
                            continue;
                        }
                        Text = jsonObject.result[0].alternative[0].transcript;
                        confidence = jsonObject.result[0].alternative[0].confidence;
                        //lbl_confidence.Content = confidence.ToString();
                        //lbl_rtxt.Content = text;
                        jsons = null;

                    }
                }
                catch (Exception)
                {

                }
                //using (read)
                //{
                //    var jObject = Newtonsoft.Json.Linq.JObject.Parse(read.Result);
                //    // Console.WriteLine((string)jObject["albums"][0]["cover_image_url"]);
                //}
                //List<string> list = Newtonsoft.Json.JsonConvert.DeserializeObject<List<string>>(sr.ReadToEnd().ToString());
                //JObject token = JObject.Parse(text);
                //JArray categories = (JArray)token["tags"][0];
                //IList<string> categoriesText = categories.Select(c => (string)c).ToList();

                //textBox.Clear();
                //textBox.AppendText(read);

                sr.Dispose();

                RecordingMark = false;
                MainWindow.IsListeningFromUser = false;

                if (Text != null)
                {
                    //TTS.Speaking(Text);//Later Pass the Text to wit.ai(New class or New folder)!!!!!
                    WitAI.StartProcessing(Text);
                }
                MainWindow.AnalysisMark = false;
                MainWindow.SayhelloMark = true;//Later Pass this line to the end of grammar analysis!!!!!
            }
        }

        public void RecordAbandon()
        {
            if (RecordAnalysisMark)
            {
                if (record != null)
                {
                    record.StopRecording();
                    record.Dispose();
                    record = null;
                }
                if (wavewriter != null)
                {
                    wavewriter.Dispose();
                    wavewriter = null;
                }
            }
        }
    }
}
