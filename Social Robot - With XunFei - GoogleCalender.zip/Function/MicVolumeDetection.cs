﻿using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialRobot.Function
{
    class MicVolumeDetection
    {
        private WaveIn waveIn;
        private NAudio.CoreAudioApi.MMDeviceEnumerator MMDE;
        private NAudio.CoreAudioApi.MMDeviceCollection DevCol;
        private NAudio.CoreAudioApi.MMDevice Dev;
        private bool IsRecording = false;
        private Action _VolumeThresholdExceed;
        private Action _VolumeThresholdExceedCache;
        private int[] VolumeBuffer = new int[3];
        private short VolumeBufferPointer = 0;
        public Action VolumeThresholdExceed     //this is not an event and only can be subcribed once
        {
            set
            {
                _VolumeThresholdExceed = value;
                _VolumeThresholdExceedCache = value;
            }
        }
        public event EventHandler<int> VolumeChanged;
        public event EventHandler<int> VolumeChangedGradiently;
        private double thersHold = 0.3;
        public int Thershold
        {
            get
            {
                return (int)(thersHold * 100);
            }
            set
            {
                if (value > 100 || value < 0) throw new Exception("Range os thershold is 0~100");
                else thersHold = (double)value / 100;
            }
        }

        public void SetDeviceContainsDeviceName(string name)
        {
            Dev = DevCol.Where(dev => dev.DeviceFriendlyName.Contains(name)).FirstOrDefault();
        }
        public MicVolumeDetection()
        {
            int audio_rate = 16000;
            int audio_byte = 16;
            int audio_channle = 1;
            waveIn = new WaveIn();
            waveIn.DeviceNumber = 0;
            waveIn.WaveFormat = new WaveFormat(audio_rate, audio_byte, audio_channle);
            waveIn.BufferMilliseconds = 100;
            MMDE = new NAudio.CoreAudioApi.MMDeviceEnumerator();
            DevCol = MMDE.EnumerateAudioEndPoints(NAudio.CoreAudioApi.DataFlow.Capture, NAudio.CoreAudioApi.DeviceState.Active);
            Dev = DevCol.FirstOrDefault();
            waveIn.StartRecording();
            IsRecording = true;
            waveIn.DataAvailable += ((object sender, WaveInEventArgs e) =>
            {
                VolumeChanged?.Invoke(sender, (int)(Dev.AudioMeterInformation.MasterPeakValue * 100));

                if(VolumeChangedGradiently != null)
                {
                    if (VolumeBufferPointer < VolumeBuffer.Length - 1) VolumeBufferPointer++;
                    else VolumeBufferPointer = 0;
                    VolumeBuffer[VolumeBufferPointer] = (int)(Dev.AudioMeterInformation.MasterPeakValue * 100);
                    int avr = 0;
                    for (int i = 0; i < VolumeBuffer.Length; i++) avr += (int)(VolumeBuffer[i] / (float)VolumeBuffer.Length);
                    VolumeChangedGradiently(sender, avr);
                }

                if (Dev.AudioMeterInformation.MasterPeakValue > thersHold && _VolumeThresholdExceed!=null)
                    _VolumeThresholdExceed();
            });
        }

        public void StopDetect()
        {
            if (IsRecording)
            {
                waveIn.StopRecording();
                IsRecording = false;
            }
        }

        public void StartDetect()
        {
            if (!IsRecording)
            {
                waveIn.StartRecording();
                IsRecording = true;
            }
        }

        public void UnsubscribeVolumeThresholdExceed()
        {
            _VolumeThresholdExceed = null;
        }

        public void ResubscribeVolumeThresholdExceed()
        {
            _VolumeThresholdExceed = _VolumeThresholdExceedCache;
        }
    }
}
