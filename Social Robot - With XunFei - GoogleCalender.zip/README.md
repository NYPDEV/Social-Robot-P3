# Social-Robot-P2
Use with Omron P2 sensor
